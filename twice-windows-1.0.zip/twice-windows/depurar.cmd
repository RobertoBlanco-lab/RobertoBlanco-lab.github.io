@echo off
rem === twice, modo DEPURACION v4: una sola instancia, todo a build\informe.txt
rem === (sin -no-shutdown: con el, cerrar la ventana mataba QEMU a lo bruto y
rem === el puerto serie se quedaba sin vaciar en el fichero)
rem === Ejecutar desde la carpeta de twice (doble clic). Al acabar, subir
rem === el fichero build\informe.txt (uno solo).
setlocal
cd /d "%~dp0"
title twice (depuracion)

rem --- Donde esta QEMU: igual que en arrancar.cmd ---
set "QEMU="
set "QIMG="
set "QDIR="
call :mirar "qemu"
if not defined QEMU call :mirar "%ProgramFiles%\qemu"
if not defined QEMU call :mirar "%ProgramW6432%\qemu"
if not defined QEMU call :mirar "%LOCALAPPDATA%\Programs\qemu"
if not defined QEMU (
  for /f "delims=" %%P in ('where qemu-system-aarch64.exe 2^>nul') do (
    set "QEMU=%%P"
    set "QDIR=%%~dpP"
    set "QIMG=%%~dpPqemu-img.exe"
  )
)
if not defined QEMU (
  echo No encuentro QEMU. Instalalo una vez desde https://qemu.weilnetz.de/w64/
  start "" https://qemu.weilnetz.de/w64/
  pause & exit /b 1
)
echo   QEMU: %QEMU%

if not exist build mkdir build

rem --- Si hay un hipervisor mas reciente en Descargas, se pone solo: asi no
rem --- se depura por descuido una version antigua ---
if exist nuevo-hv.cmd call nuevo-hv.cmd

rem Si hay otro QEMU de twice abierto, se cierra: dos a la vez se pelean por
rem los discos y el segundo muere con "error 1".
tasklist /fi "imagename eq qemu-system-aarch64.exe" | find /i "qemu-system-aarch64.exe" >nul && (
  echo Habia otro QEMU abierto: lo cierro.
  taskkill /f /im qemu-system-aarch64.exe >nul 2>&1
  timeout /t 2 >nul
)

rem Discos de 32 MiB. Los de 128 MiB de una prueba anterior se tiran: con
rem ellos QEMU se moria a los pocos segundos en este PC (solo llevan el
rem indice, que se reconstruye solo).
for %%d in (disco-darwin disco-nt disco) do (
  if exist build\%%d.img for %%z in (build\%%d.img) do if not "%%~zz"=="33554432" del /q build\%%d.img
  if not exist build\%%d.img "%QIMG%" create -f raw build\%%d.img 32M >nul
)

del /q build\qemu-debug.txt build\qemu-stderr.txt build\twice-dbg.log build\informe.txt 2>nul
if not exist build\compartido mkdir build\compartido

rem --- El agente de carpetas, igual que en arrancar.cmd ---
taskkill /f /im twice-agente.exe >nul 2>&1
if "%COMPARTIR%"=="" set "COMPARTIR=%USERPROFILE%\Documents"
set "AGENTE="
if exist twice-agente.exe (
  del /q build\agente.log build\consola.log 2>nul
  start "" /b twice-agente.exe --silencioso 17321 "%COMPARTIR%" "build\compartido"
  set "AGENTE=-chardev socket,id=agente,host=127.0.0.1,port=17321,reconnect-ms=1000 -device virtio-serial-device -device virtconsole,chardev=agente"
  echo   Agente arrancado ^(twice-agente.exe^) sirviendo %COMPARTIR%
  timeout /t 3 >nul
  echo ===== agente a los 3 s ===== > build\agente-estado.txt
  tasklist /fi "imagename eq twice-agente.exe" >> build\agente-estado.txt 2>&1
  netstat -an | findstr ":17321" >> build\agente-estado.txt 2>&1
) else (
  echo   OJO: no hay twice-agente.exe en esta carpeta: twice arrancara SIN carpetas.
)

echo.
echo   twice en modo depuracion. Espera a que salga el buscador, abre las
echo   carpetas, y cuando rompa (o al cabo de 2 minutos) cierra la ventana.
echo   Los mensajes de twice se van guardando en build\twice-dbg.log.
echo.

rem --- Con que se dibuja la ventana. El hilo que pinta con SDL es el mismo que
rem --- deja pasar los accesos del sistema a sus dispositivos: si se atasca
rem --- pintando, twice se queda clavado en mitad del arranque. gtk usa otro
rem --- camino, asi que se prefiere cuando este QEMU lo trae.
set "VENTANA=-display sdl"
"%QEMU%" -display help 2>nul | findstr /b /c:"gtk" >nul && set "VENTANA=-display gtk,zoom-to-fit=on"
echo   Ventana: %VENTANA%

set "DATOS="
if exist "%QDIR%share\efi-virtio.rom" set "DATOS=-L "%QDIR%share""

echo inicio: %date% %time% > build\informe.txt
"%QEMU%" %DATOS% -name twice ^
  -machine virt,virtualization=on,gic-version=3 -cpu cortex-a72 -smp 1 -m 512 ^
  -global virtio-mmio.force-legacy=false ^
  -drive if=none,file=build\disco-darwin.img,format=raw,id=disco-darwin -device virtio-blk-device,drive=disco-darwin ^
  -drive if=none,file=build\disco-nt.img,format=raw,id=disco-nt -device virtio-blk-device,drive=disco-nt ^
  -drive if=none,file=build\disco.img,format=raw,id=disco -device virtio-blk-device,drive=disco ^
  %AGENTE% ^
  -device virtio-gpu-device -device virtio-keyboard-device -device virtio-tablet-device ^
  %VENTANA% ^
  -serial file:build\twice-dbg.log -monitor none ^
  -d guest_errors,unimp -D build\qemu-debug.txt ^
  -kernel twice-hv.elf 2>build\qemu-stderr.txt
set CODIGO=%errorlevel%
taskkill /f /im twice-agente.exe >nul 2>&1

echo fin: %date% %time%  codigo de salida de QEMU: %CODIGO% >> build\informe.txt
echo. >> build\informe.txt
echo ===== ventana ===== >> build\informe.txt
echo %VENTANA% >> build\informe.txt
"%QEMU%" -display help >> build\informe.txt 2>&1
echo. >> build\informe.txt
echo ===== QEMU ===== >> build\informe.txt
echo %QEMU% >> build\informe.txt
"%QEMU%" --version >> build\informe.txt 2>&1
echo. >> build\informe.txt
echo ===== ficheros de la carpeta ===== >> build\informe.txt
dir /b >> build\informe.txt
echo. >> build\informe.txt
echo ===== twice-hv.elf ===== >> build\informe.txt
for %%f in (twice-hv.elf) do echo %%~zf bytes  %%~tf >> build\informe.txt
certutil -hashfile twice-hv.elf MD5 >> build\informe.txt 2>&1
echo. >> build\informe.txt
echo ===== agente ===== >> build\informe.txt
for %%f in (twice-agente.exe) do echo %%~zf bytes  %%~tf >> build\informe.txt
certutil -hashfile twice-agente.exe MD5 >> build\informe.txt 2>&1
type build\agente-estado.txt >> build\informe.txt 2>nul
echo --- build\agente.log --- >> build\informe.txt
type build\agente.log >> build\informe.txt 2>nul
echo. >> build\informe.txt
echo ===== consola de twice via agente (build\consola.log) ===== >> build\informe.txt
type build\consola.log >> build\informe.txt 2>nul
echo. >> build\informe.txt
echo ===== qemu-stderr.txt ===== >> build\informe.txt
type build\qemu-stderr.txt >> build\informe.txt 2>nul
echo. >> build\informe.txt
rem Las lineas "PL011 data written to disabled UART" son la prueba de que el
rem puerto serie se apaga: antes se filtraban y por eso no se veian nunca.
echo ===== avisos del PL011 (puerto serie apagado) ===== >> build\informe.txt
findstr /c:"PL011" build\qemu-debug.txt 2>nul | find /c /v "" >> build\informe.txt
findstr /c:"PL011" build\qemu-debug.txt 2>nul >> build\informe.txt
echo. >> build\informe.txt
echo ===== qemu-debug.txt (el resto) ===== >> build\informe.txt
findstr /v /c:"PL011" build\qemu-debug.txt >> build\informe.txt 2>nul
echo. >> build\informe.txt
echo ===== twice-dbg.log (puerto serie de twice) ===== >> build\informe.txt
type build\twice-dbg.log >> build\informe.txt 2>nul

echo.
echo   ==== QEMU ha terminado con codigo %CODIGO% ====
echo   Todo esta en  build\informe.txt  : sube ese fichero y ya.
echo.
pause
exit /b %CODIGO%

rem Mira si en la carpeta %1 esta QEMU y, si esta, se queda con ella.
:mirar
if exist "%~1\qemu-system-aarch64.exe" (
  set "QEMU=%~1\qemu-system-aarch64.exe"
  set "QIMG=%~1\qemu-img.exe"
  set "QDIR=%~1\"
)
exit /b
