' Arranca twice sin ventana de consola: solo se ve la ventana grafica de twice.
' Doble clic en este fichero.
Set fso = CreateObject("Scripting.FileSystemObject")
Set sh  = CreateObject("WScript.Shell")
aqui = fso.GetParentFolderName(WScript.ScriptFullName)
sh.CurrentDirectory = aqui
' 0 = oculta la consola; True = no esperar. QEMU abre su propia ventana.
sh.Run "cmd /c """ & aqui & "\arrancar.cmd""", 0, False
