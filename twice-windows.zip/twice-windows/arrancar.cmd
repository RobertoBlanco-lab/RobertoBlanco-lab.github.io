@echo off
rem === Arranca twice en Windows: el agente de carpetas y QEMU, sin mas. ===
rem === Lo lanza twice.exe (sin consola); tambien vale con doble clic.   ===
rem === Mensajes de twice: build\twice.log  - errores: build\error.txt  ===
setlocal enabledelayedexpansion
cd /d "%~dp0"
title twice

if not exist build mkdir build
if not exist build\compartido mkdir build\compartido
del /q build\error.txt 2>nul

rem --- Si hay un hipervisor mas reciente en Descargas, se pone solo ---
if exist nuevo-hv.cmd call nuevo-hv.cmd

rem --- QEMU: el de la carpeta qemu\ (lo instala preparar.ps1); si no, el del PATH ---
set "QEMU=qemu\qemu-system-aarch64.exe"
set "QIMG=qemu\qemu-img.exe"
if not exist "%QEMU%" (
  for /f "delims=" %%P in ('where qemu-system-aarch64.exe 2^>nul') do set "QEMU=%%P"
)
if not exist "%QIMG%" (
  for /f "delims=" %%P in ('where qemu-img.exe 2^>nul') do set "QIMG=%%P"
)
"%QEMU%" --version >nul 2>&1
if errorlevel 1 (
  echo Falta QEMU. Ejecuta preparar.ps1 ^(o twice.exe, que lo instala solo^). > build\error.txt
  type build\error.txt
  pause
  exit /b 1
)
rem Con que se dibuja la ventana: gtk si este QEMU lo trae (el hilo de SDL
rem puede atascarse pintando y dejar el sistema clavado), si no, sdl.
set "VENTANA=-display sdl"
"%QEMU%" -display help 2>nul | findstr /b /c:"gtk" >nul && set "VENTANA=-display gtk,zoom-to-fit=on"

set "DATOS="
if exist "qemu\share\efi-virtio.rom" set "DATOS=-L qemu\share"

rem --- Discos de twice (32 MiB cada uno; se crean la primera vez) ---
rem Discos de 32 MiB (solo llevan el indice, que se reconstruye solo). Los de
rem otro tamano de pruebas anteriores se tiran.
for %%D in (disco-darwin disco-nt disco) do (
  if exist "build\%%D.img" for %%Z in ("build\%%D.img") do if not "%%~zZ"=="33554432" del /q "build\%%D.img"
  if not exist "build\%%D.img" "%QIMG%" create -f raw "build\%%D.img" 32M >nul 2>&1
)

rem --- Si quedo un twice abierto, se cierra: dos a la vez se pelean por los discos ---
tasklist /fi "imagename eq qemu-system-aarch64.exe" | find /i "qemu-system-aarch64.exe" >nul && (
  taskkill /f /im qemu-system-aarch64.exe >nul 2>&1
  timeout /t 2 >nul
)
taskkill /f /im twice-agente.exe >nul 2>&1

rem --- El agente: sirve la carpeta del usuario (solo lectura), la de twice y el portapapeles ---
if "%COMPARTIR%"=="" set "COMPARTIR=%USERPROFILE%\Documents"
set "PUERTO=17321"
set "AGENTE="
if exist twice-agente.exe (
  start "" /b twice-agente.exe --silencioso %PUERTO% "%COMPARTIR%" "build\compartido"
  set "AGENTE=-chardev socket,id=agente,host=127.0.0.1,port=%PUERTO%,reconnect-ms=1000 -device virtio-serial-device -device virtconsole,chardev=agente"
) else (
  echo Sin twice-agente.exe: twice arranca sin tus carpetas ^(no encontrara ficheros^). >> build\twice.log
)

"%QEMU%" %DATOS% ^
  -name twice -machine virt,virtualization=on,gic-version=3 -cpu cortex-a72 -smp 1 -m 512 ^
  -global virtio-mmio.force-legacy=false ^
  -drive if=none,file=build\disco-darwin.img,format=raw,id=dd -device virtio-blk-device,drive=dd ^
  -drive if=none,file=build\disco-nt.img,format=raw,id=dn -device virtio-blk-device,drive=dn ^
  -drive if=none,file=build\disco.img,format=raw,id=dl -device virtio-blk-device,drive=dl ^
  %AGENTE% ^
  -device virtio-gpu-device -device virtio-keyboard-device -device virtio-tablet-device ^
  %VENTANA% ^
  -serial file:build\twice.log -monitor none ^
  -kernel twice-hv.elf 2>build\qemu-error.txt
set CODIGO=%errorlevel%

taskkill /f /im twice-agente.exe >nul 2>&1

rem Cerrar la ventana de twice no es un error (QEMU devuelve codigos raros al
rem cerrarse desde la X en Windows): solo se avisa si QEMU dijo algo por stderr
rem o salio con un codigo pequeno (1..255), que es como avisa de fallos de verdad.
set "TAM=0"
for %%A in (build\qemu-error.txt) do set "TAM=%%~zA"
set "AVISAR="
if not "%TAM%"=="0" set "AVISAR=1"
if %CODIGO% GTR 0 if %CODIGO% LSS 256 set "AVISAR=1"
if defined AVISAR (
  echo QEMU se ha cerrado con codigo %CODIGO%. > build\error.txt
  type build\qemu-error.txt >> build\error.txt 2>nul
  exit /b 1
)
exit /b 0
