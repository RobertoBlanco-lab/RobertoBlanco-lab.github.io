# La primera vez: descarga QEMU para Windows y lo integra en la carpeta qemu\,
# enseñando una ventanita con barra de progreso. Lo llama arrancar.cmd solo.
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$ErrorActionPreference = "Stop"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$dest = Join-Path $PSScriptRoot "qemu"

# --- Ventana con barra ---
$f = New-Object Windows.Forms.Form
$f.Text = "twice"
$f.ClientSize = New-Object Drawing.Size(430, 116)
$f.StartPosition = "CenterScreen"
$f.FormBorderStyle = "FixedDialog"
$f.MaximizeBox = $false; $f.MinimizeBox = $false; $f.TopMost = $true
$lbl = New-Object Windows.Forms.Label
$lbl.Text = "Preparando twice — descargando QEMU (solo la primera vez)…"
$lbl.AutoSize = $true
$lbl.Location = New-Object Drawing.Point(18, 22)
$bar = New-Object Windows.Forms.ProgressBar
$bar.Style = "Marquee"; $bar.MarqueeAnimationSpeed = 25
$bar.Location = New-Object Drawing.Point(18, 56)
$bar.Size = New-Object Drawing.Size(394, 22)
$f.Controls.Add($lbl); $f.Controls.Add($bar)
$f.Show(); [Windows.Forms.Application]::DoEvents()

function fail($m) {
    try { $f.Close() } catch {}
    [Windows.Forms.MessageBox]::Show($m, "twice", 'OK', 'Error') | Out-Null
    exit 1
}

try {
    $base = "https://qemu.weilnetz.de/w64/"
    $html = (Invoke-WebRequest -UseBasicParsing $base).Content
    $ultimo = ([regex]::Matches($html, "qemu-w64-setup-\d+\.exe") | ForEach-Object { $_.Value } | Sort-Object -Unique | Select-Object -Last 1)
    if (-not $ultimo) { fail("No encuentro el instalador de QEMU en la web.") }
    $tmp = Join-Path $env:TEMP $ultimo

    $wc = New-Object Net.WebClient
    $script:done = $false; $script:err = $null
    Register-ObjectEvent $wc DownloadFileCompleted -Action {
        $script:done = $true
        if ($EventArgs.Error) { $script:err = $EventArgs.Error.Message }
    } | Out-Null
    $wc.DownloadFileAsync([Uri]($base + $ultimo), $tmp)
    while (-not $script:done) { [Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 80 }
    if ($script:err) { fail("No se pudo descargar QEMU: $script:err") }

    $lbl.Text = "Instalando QEMU…"; [Windows.Forms.Application]::DoEvents()
    if (Test-Path $dest) { Remove-Item -Recurse -Force $dest }
    # NSIS: /S silencioso, /D destino (sin comillas y al final).
    Start-Process -FilePath $tmp -ArgumentList "/S", "/D=$dest" -Wait
    Remove-Item $tmp -Force -ErrorAction SilentlyContinue

    if (-not (Test-Path (Join-Path $dest "qemu-system-aarch64.exe"))) {
        fail("No se instalo QEMU. ¿La carpeta esta en una ruta con espacios o acentos? Muevela a algo como C:\twice y reintenta.")
    }
    $f.Close()
} catch {
    fail("Fallo preparando QEMU: $($_.Exception.Message)")
}
